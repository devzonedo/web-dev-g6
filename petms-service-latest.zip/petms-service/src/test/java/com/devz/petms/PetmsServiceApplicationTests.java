package com.devz.petms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetmsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
